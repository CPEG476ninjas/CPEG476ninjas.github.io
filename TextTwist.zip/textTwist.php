<?php
    /*function decomposeResults($queryresults, $dest){
        //$queryAsArray = [];
        foreach($queryresults as $subrackanagrams){
            $dest['words'] = array_merge($dest['words'], explode('@@', $subrackanagrams['words']));
            //splits the value by '@@' into an array
            //$subrackanagrams[1] if $subrackanagrams is an array
            //otherwise we need to chop off ' "words": ' with substring like so
            
    
            //$rest = substr($subracksanagrams, 6,-1);
            //$thisRackWords = $explode("@@", $rest);
            
            //$thisRackWords = $explode("@@", $subrackanagrams[1]); 
            
            //for($i = 0; i < sizeof($thisRackWords); $i++){
                //add strings greater than size 2 to $queryAsArray
              //  if(strlen($thisRackWords[i]) > 2){
                //    array_push($queryAsArray, $thisRackWords[i]);
                }
            };
        
        //AKA $comm
        //mutate input to be (calculated) new array of words greater than size 2
        //$queryresults = $queryAsArray;
    */
    
    //This function allows us to generate a random rack of numbers
    function generate_rack($n){
        $tileBag = "AAAAAAAAABBCCDDDDEEEEEEEEEEEEFFGGGHHIIIIIIIIIJKLLLLMMNNNNNNOOOOOOOOPPQRRRRRRSSSSTTTTTTUUUUVVWWXYYZ";
        $rack_letters = substr(str_shuffle($tileBag), 0, $n);
  
        $temp = str_split($rack_letters);
        sort($temp);
        return implode($temp);
    };
    //This is code to get all of the subracks of a rack, stored in the racks array
    $myrack = generate_rack(7);
    $racks = [];
    
    for($i = 0; $i < pow(2, strlen($myrack)); $i++){
	    $ans = "";
	    for($j = 0; $j < strlen($myrack); $j++){
		    //if the jth digit of i is 1 then include letter
		    if (($i >> $j) % 2) {
		        $ans .= $myrack[$j];
		    }
	    }
	    if (strlen($ans) > 1){
  	        $racks[] = $ans;	
	    }
    }
    
    $racks = array_unique($racks);
    //used for the json encoding, what we are communicating with front end
    //and includes our rack, and the words
    $comm = array('rack' => $myrack, 'words' => array());
    
    //this is the basic way of getting a database handler from PDO, PHP's built in quasi-ORM
    $dbhandle = new PDO("sqlite:scrabble.sqlite") or die("Failed to open DB");
    if (!$dbhandle) die ($error);
    
    foreach ($racks as $rack){
        $query = 'SELECT words FROM racks WHERE length > 2 AND rack = :rack;';
        //used to prevent an SQL injection attack
        $statement = $dbhandle->prepare($query);
        $statement->bindParam(':rack', $rack, PDO::PARAM_STR);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        //echo json_encode($results);
        //$comm['words'] = $results;
        //This takes the results from the database queries and puts them into a 
        // single array in the json format
        $tmparray =[];
        foreach($results as $subrackanagrams){
            //echo json_encode($subrackanagrams);
            $comm['words'] = array_merge($comm['words'], explode('@@', $subrackanagrams['words']));
        }
    }
    
    //$tmparray = $comm['words'];
    //foreach($tmparray as $word){
        //if(strlen($word) < 3){
    
        //}
    //}
    //foreach ($comm['words'] as $word){
        //if(strlen($word) <= 2){
            //unset($comm[$word]);
        //}
    //}
    //foreach($comm['words'] as $word){
        //add strings greater than size 2 to $queryAsArray
        //if(strlen(array_search($word, ($comm['words']) < 3))){
            //unset($comm[$word]);
        //}
    //}
    //this part is perhaps overkill but I wanted to set the HTTP headers and status code
    //making to this line means everything was great with this request
    header('HTTP/1.1 200 OK');
    //this lets the browser know to expect json
    header('Content-Type: application/json');
    //this creates json and gives it back to the browser
    echo json_encode($comm);
?>