#ifndef MEMP_STD_H_ 
#define MEMP_STD_H_
using namespace std;

//if possible change our vectors to this vector and don't include the above 
//this code compiles but im not sure if it works quite the same. 


struct alignas(32) Vector: public vector {
  char elems[32];
  static void *operator new(size_t nbytes) {
    if (void *p = aligned_alloc(alignof(Vector), nbytes)) {
      return p;
    }
    throw bad_alloc();
  }
  static void operator delete(void *p) {
    free(p);
  }
};
 
