#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
/*
vector<string> split(string s) {
    vector<string> words;
    words.push_back("");
    int word_count = 0;
    
    for(int i = 0; i < s.length(); i++) {
        if(s[i] == ' ' || s[i] == '\n') { 
            word_count++; 
            words.push_back("");
            continue; 
        }
        else{
            words.back() += s[i];
        }
    }
    return words;
}
*/
int* stringToInt(string line){
    int output[line[0]-'0'];
    //use ascii values to get actual numbers so we can add them easily
    for(int i = 1, j = 0; i < line.length(); i++) {
        if(line[i] == ' ') continue;
        output [j]= line[i]-'0';
        j++;
    }
    
    return output;
}

int* polyadder(string poly_str1, string poly_str2){
    int poly1_len = poly_str1[0]-'0', poly2_len = poly_str2[0]-'0';
    int *poly1 = stringToInt(poly_str1);
    int *poly2 = stringToInt(poly_str2);
    
    if(poly2_len == poly1_len){//otherwise equal or if poly1 is greater, set poly1 size to size of output
        //set first index to length of largest one
        int output[0] = poly1_len;
        //add rest of elements
        for(int i = poly2_len; i > 1 ; i - 2){//maybe 2 again
            output[i] = (poly1[i] + poly2[i]);
        }
    }
    if(poly2_len > poly1_len){//if poly2 is > set length of poly2 as length of output
        //set first index to length of largest one
        int output[0] = poly2_len;
        //add rest of elements
        for(int i = poly1_len; i > 1 ; i - 2){//maybe 2 for i >2
            output[i] = (poly1[i] + poly2[i]);
        }
    }
    else if(poly1_len > poly2_len){
        //set first index to length of largest one
        int output[0] = poly1_len;
        //add elements
        for(int i = poly1_len; i > 1 ; i - 2){//maybe 2 for i >2
            output[i] = (poly1[i] + poly2[i]);
        }
    }
    
    
    
    //convert each poly to a chain of ints
    //first element is going to be the larger of the two first indexes. 
    //add each index individually in reverse order
    //store in a new array of ints
}

void printVector(vector<string> v){
    for (int i = 0; i <= vector.size() -1; i++){
            cout << vector[i] << "\n";
    }
}

int main(int len, char **args) {
    ifstream ifs(args[2]);
    string line;
    line.assign((istreambuf_iterator<char>(ifs)), (istreambuf_iterator<char>()));
    
    cout << line[0] << endl << line[1] << endl << line[2] << endl;
    
}